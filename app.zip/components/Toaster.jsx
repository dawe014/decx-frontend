"use client";
import { Toaster } from "sonner";

export const ToastProvider = () => {
  return <Toaster richColors position="top-right" />;
};
