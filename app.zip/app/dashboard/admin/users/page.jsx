import React from "react";
import UserManagement from "../components/UserManagement";

export default function page() {
  return (
    <div>
      <UserManagement />
    </div>
  );
}
