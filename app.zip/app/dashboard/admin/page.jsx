import React from "react";
import AdminOverview from "./components/AdminOverview";

export default function OverviewPage() {
  return (
    <div>
      <AdminOverview />
    </div>
  );
}
