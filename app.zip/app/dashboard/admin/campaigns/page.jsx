import React from "react";
import CampaignManagement from "../components/CampaignManagement";

export default function page() {
  return (
    <div>
      <CampaignManagement />
    </div>
  );
}
