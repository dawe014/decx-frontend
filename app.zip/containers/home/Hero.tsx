export default function Hero() {
  return <div>Hero</div>;
}
